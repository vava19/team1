<?php

$host = "localhost: 3307";  // server name
$dbUser = "root"; // phpmyadmin database username
$dbPwd = ""; // phpmyadmin database password
$dbName = "library"; // phpmyadmin database name


$conn = mysqli_connect('localhost','root','','library');
if($conn==TRUE)
	//echo "suce";
if ($conn->connect_error) {
    die("Error");
echo "error";
} 
?>