<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body bgcolor="87ceeb">
<center><h2> Library Managment System</h2></center>

<a href="EnterBooks.php"><center>To enter a new book information Click here</center>  </a>
<a href="EnterBooks.php"><center>To search for the book information CLick Here</center>  </a>

<a href="EnterBooks.php"><center>TO delete a Book infomration Click here</center>  </a>

<a href="EnterBooks.php"><center>to update  a Book informaiton click here</center>  </a>
<a href="EnterBooks.php"><center>To go to librarian  page click here</center>  </a>

<a href="EnterBooks.php"><center>To go to user page click here</center>  </a>

<a href="EnterBooks.php"><center>To see all books Click here</center>  </a>


</br>
<center>img src"" style = "width: 400px; height:400px;"> </center>

    
</body>
</html>