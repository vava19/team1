
book_info

*******

create table book_info (isbn int NOT NULL,
title  varchar(30),
author varchar(20),
edition varchar(15),
publication varchar(20),
PRIMARY KEY(isbn)
);


user
**********************


create table user (user_id int NOT NULL,
name varchar(30) NOT NULL,
city varchar(20),
street varchar(15),
PRIMARY KEY(user_id)
);


borrowed 
-- with candidate keys
**********************


create table borrowed (isbn int NOT NULL,
title  varchar(30),
author varchar(20),
edition varchar(15),
publication varchar(20),
user_id int,
dateissued varchar(20)
);




librarian
*******************
create table librarian (
id int NOT NULL,
name  varchar(30),
city varchar(20),
street varchar(15),
PRIMARY KEY(id)
);




managed    
here we have 2 canddate keys :   id and date issued

******

create table managed (isbn int NOT NULL,
title  varchar(30),
author varchar(20),
edition varchar(15),
publication varchar(20),
id int NOT NULL,
dateissued varchar(20);
PRIMARY KEY(isbn)
);





create table managed (isbn int NOT NULL,
dateissued varchar(20),
PRIMARY KEY(isbn)
);


